use chrono::prelude::*;
use chrono::Duration;
use chrono::Utc;
use clap::{App, Arg};
use ordered_float::OrderedFloat;
use std::convert::TryFrom;
use std::error::Error;
use std::ffi::OsString;
use std::process;
use yahoo_finance_api as yahoo;

type StockTickerSymbol = String;

#[derive(Debug, PartialEq)]
struct RunConfig {
    interval_start_utc: DateTime<Utc>,
    interval_end_utc: DateTime<Utc>,
    stock_ticker_list: Vec<StockTickerSymbol>,
}

struct CmdLineArgs {
    arg_interval_start: String,
    arg_stock_ticker_list: Vec<StockTickerSymbol>,
}

struct StockStats {
    stock_ticker: StockTickerSymbol,
    as_of_utc: DateTime<Utc>,
    latest_price: f64,
    max_price: f64,
    min_price: f64,
    pct_change_over_interval: f64,
    av_30_day: f64,
}

struct SimpleMovingAverage {
    window_size_n: usize,
    window_vals: Vec<f64>,
}

impl RunConfig {
    #[cfg(test)]
    fn new(interval_start_utc: DateTime<Utc>, interval_end_utc: DateTime<Utc>) -> RunConfig {
        let run_config = RunConfig {
            interval_start_utc,
            interval_end_utc,
            stock_ticker_list: Vec::new(),
        };
        run_config
    }

    fn new_with_sts(
        interval_start_utc: DateTime<Utc>,
        interval_end_utc: DateTime<Utc>,
        stock_ticker_list: Vec<StockTickerSymbol>,
    ) -> RunConfig {
        let mut run_config = RunConfig {
            interval_start_utc,
            interval_end_utc,
            stock_ticker_list,
        };
        run_config.stock_ticker_list.sort();
        run_config
    }
}

impl CmdLineArgs {
    // wombled from https://www.fpcomplete.com/rust/command-line-parsing-clap/

    fn new() -> Self {
        Self::new_from(std::env::args_os().into_iter()).unwrap_or_else(|_e| process::exit(1))
    }

    fn new_from<I, T>(args: I) -> Result<Self, clap::Error>
    where
        I: Iterator<Item = T>,
        T: Into<OsString> + Clone,
    {
        let app = App::new("Manning Async Rust Project step 1")
            .version("0.1.0")
            .author("AR")
            .about("Tinkering")
            .arg(Arg::with_name("interval-start")
                .short("i")
                .long("interval-start")
                .takes_value(true)
                .help("DateTime when to request stock values from"))
            .arg(Arg::with_name("stock-ticker-symbol")
                .short("s")
                .long("stock-ticker-symbol")
                .takes_value(true)
                .multiple(true)
                .help("Stock ticker symbol to include in results, either put a space between multiple symbols or repeat arg for multiple ticker symbols"))
            ;

        let matches = app.get_matches_from_safe(args)?;

        let interval_start_arg = match matches.value_of("interval-start") {
            Some(interval_start_str) => {
                String::from(interval_start_str)
            }
            None => {
                //println!("interval-start not specified as arg, using 28 days back (from now).");
                let arg_interval_start_utc = Utc::now() - Duration::days(28);
                arg_interval_start_utc.to_rfc3339()
            }
        };

        let mut cmd_line_args = CmdLineArgs {
            arg_interval_start: String::from(interval_start_arg),
            arg_stock_ticker_list: Vec::new(),
        };

        let stock_symbols_arg_list = matches.values_of("stock-ticker-symbol");
        match stock_symbols_arg_list {
            Some(stock_ticker_value_list) => {
                //println!("Stock ticker symbols specified on command line...");
                let stock_ticker_list_str: Vec<&str> = stock_ticker_value_list.collect();
                for stock_ticker_symbol in stock_ticker_list_str {
                    //println!("\tTicker: {}", &stock_ticker_symbol);
                    let sts: StockTickerSymbol = String::from(stock_ticker_symbol);
                    cmd_line_args.add_stock_ticker_symbol(sts);
                }
            }
            None => {
                eprintln!("No stock ticker symbols specified on command line, use -s TIKR");
            }
        };

        return Ok(cmd_line_args);
    }

    fn add_stock_ticker_symbol(&mut self, stock_ticker: StockTickerSymbol) {
        self.arg_stock_ticker_list.push(stock_ticker);
    }
}

impl SimpleMovingAverage {
    fn new(window_size_n: usize) -> SimpleMovingAverage {
        SimpleMovingAverage {
            window_size_n,
            window_vals: Vec::new(),
        }
    }

    fn push_val(&mut self, val: f64) -> f64 {
        self.window_vals.push(val);

        if self.window_vals.len() > self.window_size_n {
            self.window_vals.remove(0);
        }

        if self.window_vals.is_empty() {
            return 0f64;
        } else {
            let sum = self.window_vals.iter().fold(0f64, |acc, x| acc + x);
            return sum as f64 / self.window_size_n as f64;
        }
    }
}

fn main() {
    // error handling suggestion from rust in motion
    // (implementing own error type likely worth while "for real projects")

    if let Err(e) = run_application() {
        eprintln!("An error occurred: {:?}", e);
        process::exit(3);
    }
}

fn run_application() -> Result<(), Box<dyn Error>> {
    let run_config = configure_app_run()?;

    let mut stock_stats_list: Vec<StockStats> = Vec::new();

    for sts in run_config.stock_ticker_list.iter() {
        //println!("Fetching stock stats for: {}", sts);
        let stock_stats = fetch_stock_stats(&run_config, sts)?;
        //println!("As of: {}, Stock: {}, has price: {}", stock_stats.as_of_utc, stock_stats.stock_ticker, stock_stats.latest_price);
        stock_stats_list.push(stock_stats);
    }

    csv_stock_stats_stdout(&stock_stats_list);

    Ok(())
}

fn fetch_stock_stats(
    run_config: &RunConfig,
    sts: &StockTickerSymbol,
) -> Result<StockStats, Box<dyn Error>> {
    let provider = yahoo::YahooConnector::new();

    let yahoo_stock_stats = provider.get_quote_history(
        sts.as_str(),
        run_config.interval_start_utc,
        run_config.interval_end_utc,
    )?;

    let latest_quote = yahoo_stock_stats.last_quote()?;
    let as_of_unix_timestamp = i64::try_from(latest_quote.timestamp)?;

    let mut quotes = yahoo_stock_stats.quotes()?;
    quotes.sort_by(|qt1, qt2| qt1.timestamp.cmp(&qt2.timestamp));
    quotes = quotes
        .into_iter()
        .filter(|quote| quote.adjclose.is_normal())
        .collect();
    //println!("Quotes length: {}", quotes.len());

    let min_adj_close = quotes
        .iter()
        .map(|quote| quote.adjclose)
        .map(|adj_close_normal_f64| OrderedFloat(adj_close_normal_f64))
        .min()
        .unwrap()
        .into_inner();
    //println!("\tMin: {}", min_adj_close);

    let max_adj_close = quotes
        .iter()
        .map(|quote| quote.adjclose)
        .map(|adj_close_normal_f64| OrderedFloat(adj_close_normal_f64))
        .max()
        .unwrap()
        .into_inner();
    //println!("\tMax: {}", max_adj_close);

    let adj_close_list: Vec<f64> = quotes.iter().map(|quote| quote.adjclose).collect();

    let simple_moving_av_vals = n_window_sma(30, &adj_close_list).unwrap();
    let price_diff = price_diff(&adj_close_list).unwrap();

    let stock_stats = StockStats {
        stock_ticker: sts.clone(),
        as_of_utc: Utc.timestamp(as_of_unix_timestamp, 0),
        latest_price: latest_quote.adjclose,
        max_price: max_adj_close,
        min_price: min_adj_close,
        pct_change_over_interval: price_diff.0,
        av_30_day: simple_moving_av_vals[simple_moving_av_vals.len() - 1],
    };

    Ok(stock_stats)
}

fn csv_stock_stats_stdout(stock_stat_list: &[StockStats]) {
    // latest quote datetime, stock symbol, latest close price, change pct, min, max, 30d avg
    println!("Latest Quote DateTime,Symbol,Price ($),Change (%),Min,Max,30 Day Avg");
    for stock_stats in stock_stat_list {
        println!(
            "{},{},{:.2},{:.2},{:.2},{:.2},{:.2}",
            &stock_stats.as_of_utc,
            &stock_stats.stock_ticker,
            &stock_stats.latest_price,
            &stock_stats.pct_change_over_interval,
            &stock_stats.min_price,
            &stock_stats.max_price,
            &stock_stats.av_30_day
        );
    }
}

fn n_window_sma(n: usize, series: &[f64]) -> Option<Vec<f64>> {
    let mut sma = SimpleMovingAverage::new(n);
    let mut sma_vals: Vec<f64> = Vec::new();

    for &val in series {
        sma_vals.push(sma.push_val(val));
    }

    if sma_vals.is_empty() {
        return None;
    }

    Some(sma_vals)
}

fn price_diff(series: &[f64]) -> Option<(f64, f64)> {
    if series.len() < 1 {
        return None;
    }

    let change_pct = series[series.len() - 1] / series[0];
    let change_abs = series[series.len() - 1] - series[0];

    Some((change_pct, change_abs))
}

fn configure_app_run() -> Result<RunConfig, Box<dyn Error>> {
    let args = CmdLineArgs::new();
    let now_utc = Utc::now();

    let arg_interval_start_fixed_offset =
        DateTime::<FixedOffset>::parse_from_rfc3339(args.arg_interval_start.as_str())?;

    let arg_interval_start_utc = arg_interval_start_fixed_offset.into();

    let run_config =
        RunConfig::new_with_sts(arg_interval_start_utc, now_utc, args.arg_stock_ticker_list);

    Ok(run_config)
}

#[cfg(test)]
mod tests {

    use super::*;

    #[test]
    fn test_no_cmd_line_args() {
        CmdLineArgs::new_from(["exename"].iter()).unwrap();
    }

    #[test]
    fn test_single_sts() {
        let args =
            CmdLineArgs::new_from(["exename", "--stock-ticker-symbol", "AAPL"].iter()).unwrap();
        assert!(args.arg_stock_ticker_list.len() == 1);
    }

    #[test]
    fn test_single_short_sts() {
        let args = CmdLineArgs::new_from(["exename", "-s", "AAPL"].iter()).unwrap();
        assert!(args.arg_stock_ticker_list.len() == 1);
    }

    #[test]
    fn test_single_sts_no_symbol() {
        let args = CmdLineArgs::new_from(["exename", "--stock-ticker-symbol"].iter());
        match args {
            Err(_e) => {
                assert!(true);
            }
            Ok(_ok) => {
                assert!(false);
            }
        }
    }

    #[test]
    fn test_multi_sts_single_arg() {
        let args =
            CmdLineArgs::new_from(["exename", "--stock-ticker-symbol", "AAPL", "GOOG"].iter())
                .unwrap();
        assert!(args.arg_stock_ticker_list.len() == 2);

        assert!(args.arg_stock_ticker_list.iter().any(|sts| sts == "AAPL"));
        assert!(args.arg_stock_ticker_list.iter().any(|sts| sts == "GOOG"));
    }

    #[test]
    fn test_multi_sts_multi_arg() {
        let args = CmdLineArgs::new_from(
            [
                "exename",
                "--stock-ticker-symbol",
                "AAPL",
                "--stock-ticker-symbol",
                "GOOG",
            ]
            .iter(),
        )
        .unwrap();
        assert!(args.arg_stock_ticker_list.len() == 2);

        assert!(args.arg_stock_ticker_list.iter().any(|sts| sts == "AAPL"));
        assert!(args.arg_stock_ticker_list.iter().any(|sts| sts == "GOOG"));
    }

    #[test]
    fn test_period_start_arg() {
        let test_interval_start = "2021-05-20T12:00:00+00:00";
        let args =
            CmdLineArgs::new_from(["exename", "--interval-start", test_interval_start].iter())
                .unwrap();
        assert_eq!(test_interval_start.to_string(), args.arg_interval_start);
    }

    #[test]
    fn test_call_yahoo_finance_api() {
        let arg_interval_start_utc = Utc::now() - Duration::days(90);
        let mut run_config = RunConfig::new(arg_interval_start_utc, Utc::now());
        run_config.stock_ticker_list.push("AAPL".to_string());

        let _stock_stats =
            fetch_stock_stats(&run_config, &run_config.stock_ticker_list[0]).unwrap();
    }

    #[test]
    fn test_sma() {
        let test_series = vec![2.2, 5.6, 4.3, 8.9, 6.3, 5.1, 0.3, 6.5, 3.2];
        let sma_vals = n_window_sma(3, &test_series).unwrap();
        assert_eq!(sma_vals.len(), 9);
        assert_eq!(sma_vals[8], (0.3 + 6.5 + 3.2) / 3.0);
    }

    #[test]
    fn test_price_diff() {
        let test_series = vec![4.3, 8.9, 6.3, 5.1, 0.3];
        let price_diff = price_diff(&test_series).unwrap();
        assert_eq!(price_diff.0, 0.3 / 4.3);
        assert_eq!(price_diff.1, 0.3 - 4.3);
    }

    #[test]
    fn test_csv_stock_stats_stdout() {
        let arg_interval_start_utc = Utc::now() - Duration::days(90);
        let mut run_config = RunConfig::new(arg_interval_start_utc, Utc::now());
        run_config.stock_ticker_list.push("AAPL".to_string());

        let stock_stats = fetch_stock_stats(&run_config, &run_config.stock_ticker_list[0]).unwrap();

        let stock_stats_list = vec![stock_stats];

        csv_stock_stats_stdout(&stock_stats_list);
    }
}
