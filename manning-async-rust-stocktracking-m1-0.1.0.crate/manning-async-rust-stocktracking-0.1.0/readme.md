# Manning Building a Stock Tracking CLI With Async Streams in Rust

As the solution for milestone 1 of the Manning course "Building a Stock 
Tracking CLI With Async Streams in Rust", this package creates a command line 
app that can collect stock price related statistics from the Yahoo Finance API.

There is nothing async about this implementation yet!

The program is a CLI (command line interface) to be run from a terminal with a 
command such as:

    ./manning-async-rust-stocktracking \
        --interval-start 2021-03-20T12:00:00+00:00 \
        --stock-ticker-symbol AAPL MSFT GOOG UBER IBM

The response will be printed to stdout in the form:

    Latest Quote DateTime,Symbol,Price ($),Change (%),Min,Max,30 Day Avg
    2021-06-10 13:30:00 UTC,AAPL,126.11,1.03,119.70,134.61,126.60
    2021-06-10 13:30:00 UTC,GOOG,2521.60,1.23,2035.55,2521.60,2388.18
    2021-06-10 13:30:00 UTC,IBM,150.54,1.17,129.02,151.28,145.22
    2021-06-10 13:30:00 UTC,MSFT,257.24,1.10,231.32,261.37,248.63
    2021-06-10 13:30:00 UTC,UBER,49.55,0.90,43.81,60.74,49.42
